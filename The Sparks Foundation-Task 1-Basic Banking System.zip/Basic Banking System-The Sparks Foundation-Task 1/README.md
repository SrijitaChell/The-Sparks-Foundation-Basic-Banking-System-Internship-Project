# The-Sparks-Foundation-Basic-Banking-System-Internship-Project
I was supposed to create a basic banking website for the Sparks Foundation as an internship project.
